</div><!-- /fx-wrapper -->
<?php wp_footer(); ?>

</body>
</html>