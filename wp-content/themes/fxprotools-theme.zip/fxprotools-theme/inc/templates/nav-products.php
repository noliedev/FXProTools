<nav class="navbar fx-navbar-sub">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ul class="fx-nav-options">
					<li class="dashboard"><a href="<?php bloginfo('url');?>/basic-training" title="Product Icon"><i class="fa fa-th-large" aria-hidden="true"></i></a></li>
					<li><a href="<?php bloginfo('url');?>/basic-training">Basic Training</a></li>
					<li><a href="<?php bloginfo('url');?>/advanced-training">Advance Training</a></li>
					<li><a href="<?php bloginfo('url');?>/scanner">Market Scanner</a></li>
					<li><a href="<?php bloginfo('url');?>/auto-trader">Auto Trader</a></li>
					<li><a href="<?php bloginfo('url');?>/coaching">Coaching / Webinars </a></li>
				</ul>
			</div>
		</div>
	</div>
</nav>