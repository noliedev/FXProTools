<nav class="navbar fx-navbar-sub">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ul class="fx-nav-options">
					<li class="dashboard"><a href="<?php bloginfo('url');?>/marketing/funnels" title="Marketing Icon"><i class="fa fa-th-large" aria-hidden="true"></i></a></li>
					<li><a href="<?php bloginfo('url');?>/marketing/funnels">Sales Funnels</a></li>
					<li><a href="<?php bloginfo('url');?>/marketing/stats">Stats</a></li>
					<li><a href="<?php bloginfo('url');?>/marketing/contacts">Contacts</a></li>
				</ul>
			</div>
		</div>
	</div>
</nav>