<nav class="navbar fx-navbar-sub">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ul class="fx-nav-options">
					<li class="dashboard"><a href="#" title="Team Icon"><i class="fa fa-th-large" aria-hidden="true"></i></a></li>
					<li><a href="#">Referred Members</a></li>
					<li><a href="#">Direct Downline</a></li>
					<li><a href="#">Unilevel Tree View</a></li>
					<li><a href="#">Genaology Tree</a></li>
					<li><a href="#">Direct Upline</a></li>
				</ul>
			</div>
		</div>
	</div>
</nav>