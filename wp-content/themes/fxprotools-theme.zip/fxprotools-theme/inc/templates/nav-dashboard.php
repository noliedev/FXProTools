<nav class="navbar fx-navbar-sub">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ul class="fx-nav-options">
					<li class="dashboard"><a href="<?php bloginfo('url'); ?>/dashboard" title="Dashboard Icon"><i class="fa fa-th-large" aria-hidden="true"></i></a></li>
					<li><a href="<?php bloginfo('url'); ?>/dashboard">1.) User Orientation</a></li>
					<li><a href="<?php bloginfo('url'); ?>/access-products">2.) Products </a></li>
					<li><a href="<?php bloginfo('url'); ?>/referral-program">3.) Refer 3 Program</a></li>
				</ul>
			</div>
		</div>
	</div>
</nav>