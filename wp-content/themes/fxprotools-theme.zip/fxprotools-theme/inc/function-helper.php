<?php
/**
 * -----------------------------
 * Fxprotools - Helper Functions
 * -----------------------------
 * All helper functions
 */

// Styled Array
 function dd($array) {
	echo '<pre>';
	print_r($array);
	echo '</pre>';
}